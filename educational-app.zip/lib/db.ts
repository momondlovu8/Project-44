"use client"

import { openDB, type DBSchema, type IDBPDatabase } from "idb"

interface StudyHubDB extends DBSchema {
  textbooks: {
    key: string
    value: {
      id: string
      subject: string
      chapter: string
      topic: string
      content: string
      lastAccessed: Date
    }
  }
  notes: {
    key: string
    value: {
      id: string
      textbookId: string
      paragraph: string
      note: string
      createdAt: Date
      updatedAt: Date
      synced: boolean
    }
  }
  highlights: {
    key: string
    value: {
      id: string
      textbookId: string
      text: string
      createdAt: Date
      synced: boolean
    }
  }
  examPapers: {
    key: string
    value: {
      id: string
      subject: string
      title: string
      type: string
      year: string
      questions: number
      duration: number
      content: any
      lastAccessed: Date
    }
  }
  progress: {
    key: string
    value: {
      id: string
      contentId: string
      contentType: "textbook" | "exam"
      progress: number
      lastAccessed: Date
      synced: boolean
    }
  }
}

let dbInstance: IDBPDatabase<StudyHubDB> | null = null

export async function getDB() {
  if (!dbInstance) {
    dbInstance = await openDB<StudyHubDB>("studyhub-db", 1, {
      upgrade(db) {
        // Create stores
        db.createObjectStore("textbooks", { keyPath: "id" })
        db.createObjectStore("notes", { keyPath: "id" })
        db.createObjectStore("highlights", { keyPath: "id" })
        db.createObjectStore("examPapers", { keyPath: "id" })
        db.createObjectStore("progress", { keyPath: "id" })
      },
    })
  }
  return dbInstance
}

// Textbook functions
export async function saveTextbook(textbook: StudyHubDB["textbooks"]["value"]) {
  const db = await getDB()
  return db.put("textbooks", {
    ...textbook,
    lastAccessed: new Date(),
  })
}

export async function getTextbook(id: string) {
  const db = await getDB()
  return db.get("textbooks", id)
}

export async function getAllTextbooks() {
  const db = await getDB()
  return db.getAll("textbooks")
}

export async function deleteTextbook(id: string) {
  const db = await getDB()
  return db.delete("textbooks", id)
}

// Notes functions
export async function saveNote(note: StudyHubDB["notes"]["value"]) {
  const db = await getDB()
  return db.put("notes", {
    ...note,
    updatedAt: new Date(),
    synced: false,
  })
}

export async function getNote(id: string) {
  const db = await getDB()
  return db.get("notes", id)
}

export async function getNotesByTextbook(textbookId: string) {
  const db = await getDB()
  const allNotes = await db.getAll("notes")
  return allNotes.filter((note) => note.textbookId === textbookId)
}

export async function deleteNote(id: string) {
  const db = await getDB()
  return db.delete("notes", id)
}

// Highlights functions
export async function saveHighlight(highlight: StudyHubDB["highlights"]["value"]) {
  const db = await getDB()
  return db.put("highlights", {
    ...highlight,
    createdAt: new Date(),
    synced: false,
  })
}

export async function getHighlightsByTextbook(textbookId: string) {
  const db = await getDB()
  const allHighlights = await db.getAll("highlights")
  return allHighlights.filter((highlight) => highlight.textbookId === textbookId)
}

export async function deleteHighlight(id: string) {
  const db = await getDB()
  return db.delete("highlights", id)
}

// Exam papers functions
export async function saveExamPaper(examPaper: StudyHubDB["examPapers"]["value"]) {
  const db = await getDB()
  return db.put("examPapers", {
    ...examPaper,
    lastAccessed: new Date(),
  })
}

export async function getExamPaper(id: string) {
  const db = await getDB()
  return db.get("examPapers", id)
}

export async function getAllExamPapers() {
  const db = await getDB()
  return db.getAll("examPapers")
}

export async function deleteExamPaper(id: string) {
  const db = await getDB()
  return db.delete("examPapers", id)
}

// Progress tracking functions
export async function saveProgress(progress: StudyHubDB["progress"]["value"]) {
  const db = await getDB()
  return db.put("progress", {
    ...progress,
    lastAccessed: new Date(),
    synced: false,
  })
}

export async function getProgress(contentId: string, contentType: "textbook" | "exam") {
  const db = await getDB()
  const allProgress = await db.getAll("progress")
  return allProgress.find((p) => p.contentId === contentId && p.contentType === contentType)
}

// Sync functions
export async function getUnsyncedItems() {
  const db = await getDB()

  const notes = await db.getAll("notes")
  const unsyncedNotes = notes.filter((note) => !note.synced)

  const highlights = await db.getAll("highlights")
  const unsyncedHighlights = highlights.filter((highlight) => !highlight.synced)

  const progress = await db.getAll("progress")
  const unsyncedProgress = progress.filter((p) => !p.synced)

  return {
    notes: unsyncedNotes,
    highlights: unsyncedHighlights,
    progress: unsyncedProgress,
  }
}

export async function markAsSynced(store: "notes" | "highlights" | "progress", id: string) {
  const db = await getDB()
  const item = await db.get(store, id)
  if (item) {
    item.synced = true
    return db.put(store, item)
  }
}

