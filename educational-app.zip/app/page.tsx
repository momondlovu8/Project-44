import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, FileText, Home, Search, Settings, BookMarked } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <h1 className="text-xl font-bold flex items-center">
            <BookOpen className="mr-2 h-5 w-5" />
            StudyHub
          </h1>
          <div className="flex items-center gap-2">
            <ModeToggle />
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        <section className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Welcome to StudyHub</h2>
          <p className="text-muted-foreground mb-4">
            Your comprehensive Grade 11 learning companion that works online and offline.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            <Card>
              <CardHeader>
                <CardTitle>Continue Learning</CardTitle>
                <CardDescription>Pick up where you left off</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-24 bg-muted rounded-md flex items-center justify-center">
                  <p className="text-muted-foreground">Mathematics - Chapter 4: Trigonometry</p>
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/textbook/mathematics/chapter-4">Continue</Link>
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Practice Tests</CardTitle>
                <CardDescription>Test your knowledge with past papers</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-24 bg-muted rounded-md flex items-center justify-center">
                  <p className="text-muted-foreground">Science - Term 2 Exam Papers</p>
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild variant="outline" className="w-full">
                  <Link href="/exams/science">Start Practice</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>

          <Tabs defaultValue="subjects" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="subjects">Subjects</TabsTrigger>
              <TabsTrigger value="recent">Recent</TabsTrigger>
              <TabsTrigger value="downloads">Downloads</TabsTrigger>
            </TabsList>
            <TabsContent value="subjects">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4">
                {subjects.map((subject) => (
                  <Link
                    key={subject.id}
                    href={`/textbook/${subject.id}`}
                    className="flex flex-col items-center p-4 border rounded-lg hover:bg-accent transition-colors"
                  >
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
                      <subject.icon className="h-6 w-6 text-primary" />
                    </div>
                    <span className="text-center font-medium">{subject.name}</span>
                  </Link>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="recent">
              <div className="space-y-4 mt-4">
                {recentItems.map((item, index) => (
                  <Link
                    key={index}
                    href={item.path}
                    className="flex items-center p-3 border rounded-lg hover:bg-accent transition-colors"
                  >
                    <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center mr-3">
                      <BookMarked className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">{item.title}</h3>
                      <p className="text-sm text-muted-foreground">{item.subject}</p>
                    </div>
                  </Link>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="downloads">
              <div className="space-y-4 mt-4">
                {downloadedItems.map((item, index) => (
                  <div key={index} className="flex items-center p-3 border rounded-lg">
                    <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center mr-3">
                      <BookMarked className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">{item.title}</h3>
                      <p className="text-sm text-muted-foreground">{item.subject}</p>
                    </div>
                    <Button variant="ghost" size="sm">
                      Open
                    </Button>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </section>
      </main>

      <footer className="border-t py-2">
        <div className="container mx-auto">
          <nav className="flex justify-around">
            <Link href="/" className="flex flex-col items-center p-2 text-primary">
              <Home className="h-5 w-5" />
              <span className="text-xs">Home</span>
            </Link>
            <Link href="/textbook" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Textbook</span>
            </Link>
            <Link href="/exams" className="flex flex-col items-center p-2">
              <FileText className="h-5 w-5" />
              <span className="text-xs">Exams</span>
            </Link>
            <Link href="/search" className="flex flex-col items-center p-2">
              <Search className="h-5 w-5" />
              <span className="text-xs">Search</span>
            </Link>
            <Link href="/settings" className="flex flex-col items-center p-2">
              <Settings className="h-5 w-5" />
              <span className="text-xs">Settings</span>
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}

const subjects = [
  { id: "mathematics", name: "Mathematics", icon: BookOpen },
  { id: "science", name: "Science", icon: BookOpen },
  { id: "english", name: "English", icon: BookOpen },
  { id: "history", name: "History", icon: BookOpen },
  { id: "geography", name: "Geography", icon: BookOpen },
  { id: "economics", name: "Economics", icon: BookOpen },
]

const recentItems = [
  { title: "Quadratic Equations", subject: "Mathematics", path: "/textbook/mathematics/quadratic-equations" },
  { title: "Chemical Reactions", subject: "Science", path: "/textbook/science/chemical-reactions" },
  { title: "Essay Writing", subject: "English", path: "/textbook/english/essay-writing" },
  { title: "World War II", subject: "History", path: "/textbook/history/world-war-ii" },
]

const downloadedItems = [
  { title: "Algebra Fundamentals", subject: "Mathematics" },
  { title: "Periodic Table", subject: "Science" },
  { title: "Grammar Rules", subject: "English" },
  { title: "Ancient Civilizations", subject: "History" },
]

