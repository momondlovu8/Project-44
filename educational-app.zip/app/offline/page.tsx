import { Button } from "@/components/ui/button"
import { WifiOff, Home } from "lucide-react"
import Link from "next/link"

export default function OfflinePage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mb-6">
        <WifiOff className="h-10 w-10 text-muted-foreground" />
      </div>

      <h1 className="text-2xl font-bold mb-2">You're offline</h1>
      <p className="text-center text-muted-foreground mb-6 max-w-md">
        The page you're trying to access isn't available offline. Please check your internet connection and try again.
      </p>

      <div className="space-y-4">
        <Button asChild>
          <Link href="/">
            <Home className="mr-2 h-4 w-4" />
            Go to Home
          </Link>
        </Button>

        <div className="text-center">
          <p className="text-sm text-muted-foreground">You can still access your downloaded content while offline</p>
        </div>
      </div>
    </div>
  )
}

