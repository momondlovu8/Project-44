/// <reference lib="webworker" />

// This service worker can be customized!
// See https://developers.google.com/web/tools/workbox/modules
// for the list of available Workbox modules, or add any other
// code you'd like.

declare const self: ServiceWorkerGlobalScope

const CACHE_NAME = "studyhub-v1"
const OFFLINE_URL = "/offline"

// Add all the files to precache
const precacheResources = ["/", "/offline", "/textbook", "/exams", "/search", "/settings"]

// Install event - precache all essential resources
self.addEventListener("install", (event) => {
  console.log("Service worker installing...")

  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(precacheResources))
      .then(() => self.skipWaiting()),
  )
})

// Activate event - clean up old caches
self.addEventListener("activate", (event) => {
  console.log("Service worker activating...")

  event.waitUntil(
    caches
      .keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames
            .filter((cacheName) => {
              return cacheName !== CACHE_NAME
            })
            .map((cacheName) => {
              return caches.delete(cacheName)
            }),
        )
      })
      .then(() => self.clients.claim()),
  )
})

// Fetch event - serve from cache or network
self.addEventListener("fetch", (event) => {
  // Skip cross-origin requests
  if (!event.request.url.startsWith(self.location.origin)) {
    return
  }

  // For navigation requests, try the network first, fall back to the offline page
  if (event.request.mode === "navigate") {
    event.respondWith(
      fetch(event.request).catch(() => {
        return caches.match(OFFLINE_URL) || caches.match("/")
      }),
    )
    return
  }

  // For other requests, try the cache first, fall back to the network
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse
      }

      return fetch(event.request)
        .then((response) => {
          // Cache successful responses for future use
          if (response && response.status === 200) {
            const responseToCache = response.clone()
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseToCache)
            })
          }
          return response
        })
        .catch(() => {
          // If both cache and network fail, return a generic fallback
          if (event.request.headers.get("Accept")?.includes("image")) {
            return new Response("", {
              status: 200,
              headers: { "Content-Type": "image/svg+xml" },
            })
          }
          return new Response("Network error occurred", {
            status: 408,
            headers: { "Content-Type": "text/plain" },
          })
        })
    }),
  )
})

// Background sync for offline actions
self.addEventListener("sync", (event) => {
  if (event.tag === "sync-notes") {
    event.waitUntil(syncNotes())
  } else if (event.tag === "sync-highlights") {
    event.waitUntil(syncHighlights())
  }
})

async function syncNotes() {
  // Implementation to sync notes when back online
  console.log("Syncing notes...")
  // This would normally fetch pending notes from IndexedDB and send to server
}

async function syncHighlights() {
  // Implementation to sync highlights when back online
  console.log("Syncing highlights...")
  // This would normally fetch pending highlights from IndexedDB and send to server
}

export {}

