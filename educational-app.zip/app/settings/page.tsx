import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { BookOpen, ChevronLeft, FileText, Search, Settings } from "lucide-react"
import Link from "next/link"
import { ThemeSelector } from "@/components/theme-selector"

export default function SettingsPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-3 flex items-center">
          <Link href="/" className="mr-3">
            <ChevronLeft className="h-5 w-5" />
          </Link>
          <h1 className="text-xl font-bold flex items-center">
            <Settings className="mr-2 h-5 w-5" />
            Settings
          </h1>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="grid gap-6 max-w-md mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Display Settings</CardTitle>
              <CardDescription>Customize how content appears</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="theme">Theme</Label>
                <ThemeSelector />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label htmlFor="font-size">Font Size</Label>
                  <span className="text-sm">Medium</span>
                </div>
                <Slider id="font-size" defaultValue={[50]} max={100} step={1} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Reading Preferences</CardTitle>
              <CardDescription>Customize your reading experience</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="highlight">Enable Highlighting</Label>
                <Switch id="highlight" defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="notes">Enable Notes</Label>
                <Switch id="notes" defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="bookmarks">Enable Bookmarks</Label>
                <Switch id="bookmarks" defaultChecked />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Offline Access</CardTitle>
              <CardDescription>Manage downloaded content</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="auto-download">Auto-download new content</Label>
                <Switch id="auto-download" />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="wifi-only">Download on Wi-Fi only</Label>
                <Switch id="wifi-only" defaultChecked />
              </div>

              <div className="space-y-2">
                <Label>Storage Used</Label>
                <div className="w-full bg-secondary rounded-full h-2.5">
                  <div className="bg-primary h-2.5 rounded-full w-[45%]"></div>
                </div>
                <div className="flex justify-between text-sm">
                  <span>450 MB used</span>
                  <span>1 GB total</span>
                </div>
              </div>

              <Button variant="outline" className="w-full">
                Clear Downloaded Content
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>About</CardTitle>
              <CardDescription>Application information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span>Version</span>
                <span>1.0.0</span>
              </div>
              <div className="flex justify-between">
                <span>Last Updated</span>
                <span>March 19, 2023</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="border-t py-2">
        <div className="container mx-auto">
          <nav className="flex justify-around">
            <Link href="/" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Home</span>
            </Link>
            <Link href="/textbook" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Textbook</span>
            </Link>
            <Link href="/exams" className="flex flex-col items-center p-2">
              <FileText className="h-5 w-5" />
              <span className="text-xs">Exams</span>
            </Link>
            <Link href="/search" className="flex flex-col items-center p-2">
              <Search className="h-5 w-5" />
              <span className="text-xs">Search</span>
            </Link>
            <Link href="/settings" className="flex flex-col items-center p-2 text-primary">
              <Settings className="h-5 w-5" />
              <span className="text-xs">Settings</span>
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}

