import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, ChevronLeft, Download, FileText, Search } from "lucide-react"
import Link from "next/link"

export default function ExamsPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-3 flex items-center">
          <Link href="/" className="mr-3">
            <ChevronLeft className="h-5 w-5" />
          </Link>
          <h1 className="text-xl font-bold flex items-center">
            <FileText className="mr-2 h-5 w-5" />
            Exam Papers
          </h1>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search exam papers..." className="pl-9" />
        </div>

        <Tabs defaultValue="all" className="w-full mb-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="practice">Practice</TabsTrigger>
            <TabsTrigger value="past">Past Papers</TabsTrigger>
            <TabsTrigger value="saved">Saved</TabsTrigger>
          </TabsList>
          <TabsContent value="all">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              {examPapers.map((paper, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle>{paper.subject}</CardTitle>
                    <CardDescription>
                      {paper.type} - {paper.year}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium">{paper.title}</p>
                          <p className="text-sm text-muted-foreground">
                            {paper.questions} questions • {paper.duration} minutes
                          </p>
                        </div>
                        <Button variant="ghost" size="icon">
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex gap-2">
                    <Button asChild className="flex-1">
                      <Link href={`/exams/${paper.id}`}>Start</Link>
                    </Button>
                    <Button variant="outline" className="flex-1">
                      View Solutions
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="practice">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              {examPapers
                .filter((p) => p.type === "Practice Test")
                .map((paper, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <CardTitle>{paper.subject}</CardTitle>
                      <CardDescription>
                        {paper.type} - {paper.year}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium">{paper.title}</p>
                            <p className="text-sm text-muted-foreground">
                              {paper.questions} questions • {paper.duration} minutes
                            </p>
                          </div>
                          <Button variant="ghost" size="icon">
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="flex gap-2">
                      <Button asChild className="flex-1">
                        <Link href={`/exams/${paper.id}`}>Start</Link>
                      </Button>
                      <Button variant="outline" className="flex-1">
                        View Solutions
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
            </div>
          </TabsContent>
          <TabsContent value="past">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              {examPapers
                .filter((p) => p.type === "Past Paper")
                .map((paper, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <CardTitle>{paper.subject}</CardTitle>
                      <CardDescription>
                        {paper.type} - {paper.year}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium">{paper.title}</p>
                            <p className="text-sm text-muted-foreground">
                              {paper.questions} questions • {paper.duration} minutes
                            </p>
                          </div>
                          <Button variant="ghost" size="icon">
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="flex gap-2">
                      <Button asChild className="flex-1">
                        <Link href={`/exams/${paper.id}`}>Start</Link>
                      </Button>
                      <Button variant="outline" className="flex-1">
                        View Solutions
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
            </div>
          </TabsContent>
          <TabsContent value="saved">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              {examPapers
                .filter((_, i) => i < 2)
                .map((paper, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <CardTitle>{paper.subject}</CardTitle>
                      <CardDescription>
                        {paper.type} - {paper.year}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium">{paper.title}</p>
                            <p className="text-sm text-muted-foreground">
                              {paper.questions} questions • {paper.duration} minutes
                            </p>
                          </div>
                          <Button variant="ghost" size="icon">
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="flex gap-2">
                      <Button asChild className="flex-1">
                        <Link href={`/exams/${paper.id}`}>Start</Link>
                      </Button>
                      <Button variant="outline" className="flex-1">
                        View Solutions
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <footer className="border-t py-2">
        <div className="container mx-auto">
          <nav className="flex justify-around">
            <Link href="/" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Home</span>
            </Link>
            <Link href="/textbook" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Textbook</span>
            </Link>
            <Link href="/exams" className="flex flex-col items-center p-2 text-primary">
              <FileText className="h-5 w-5" />
              <span className="text-xs">Exams</span>
            </Link>
            <Link href="/search" className="flex flex-col items-center p-2">
              <Search className="h-5 w-5" />
              <span className="text-xs">Search</span>
            </Link>
            <Link href="/settings" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Settings</span>
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}

const examPapers = [
  {
    id: "math-practice-1",
    subject: "Mathematics",
    type: "Practice Test",
    year: "2023",
    title: "Algebra and Functions",
    questions: 30,
    duration: 90,
  },
  {
    id: "science-past-1",
    subject: "Science",
    type: "Past Paper",
    year: "2022",
    title: "Physics and Chemistry",
    questions: 45,
    duration: 120,
  },
  {
    id: "english-practice-1",
    subject: "English",
    type: "Practice Test",
    year: "2023",
    title: "Comprehension and Writing",
    questions: 25,
    duration: 90,
  },
  {
    id: "history-past-1",
    subject: "History",
    type: "Past Paper",
    year: "2022",
    title: "Modern History",
    questions: 35,
    duration: 120,
  },
  {
    id: "math-past-1",
    subject: "Mathematics",
    type: "Past Paper",
    year: "2021",
    title: "Calculus and Trigonometry",
    questions: 30,
    duration: 90,
  },
  {
    id: "science-practice-1",
    subject: "Science",
    type: "Practice Test",
    year: "2023",
    title: "Biology and Ecology",
    questions: 40,
    duration: 120,
  },
]

