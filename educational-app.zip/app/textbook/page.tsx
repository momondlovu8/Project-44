import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { BookOpen, ChevronLeft, Download, Search } from "lucide-react"
import Link from "next/link"

export default function TextbookPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-3 flex items-center">
          <Link href="/" className="mr-3">
            <ChevronLeft className="h-5 w-5" />
          </Link>
          <h1 className="text-xl font-bold flex items-center">
            <BookOpen className="mr-2 h-5 w-5" />
            Textbooks
          </h1>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search textbooks..." className="pl-9" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {subjects.map((subject) => (
            <Card key={subject.id}>
              <CardHeader>
                <CardTitle>{subject.name}</CardTitle>
                <CardDescription>Grade 11 curriculum</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {subject.chapters.map((chapter, index) => (
                    <div key={index} className="flex justify-between items-center p-2 hover:bg-accent rounded-md">
                      <div>
                        <p className="font-medium">{chapter.title}</p>
                        <p className="text-sm text-muted-foreground">{chapter.pages} pages</p>
                      </div>
                      <Button variant="ghost" size="icon">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href={`/textbook/${subject.id}`}>View All Chapters</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </main>

      <footer className="border-t py-2">
        <div className="container mx-auto">
          <nav className="flex justify-around">
            <Link href="/" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Home</span>
            </Link>
            <Link href="/textbook" className="flex flex-col items-center p-2 text-primary">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Textbook</span>
            </Link>
            <Link href="/exams" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Exams</span>
            </Link>
            <Link href="/search" className="flex flex-col items-center p-2">
              <Search className="h-5 w-5" />
              <span className="text-xs">Search</span>
            </Link>
            <Link href="/settings" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Settings</span>
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}

const subjects = [
  {
    id: "mathematics",
    name: "Mathematics",
    chapters: [
      { title: "Chapter 1: Algebra", pages: 42 },
      { title: "Chapter 2: Functions", pages: 38 },
      { title: "Chapter 3: Calculus", pages: 45 },
      { title: "Chapter 4: Trigonometry", pages: 36 },
    ],
  },
  {
    id: "science",
    name: "Science",
    chapters: [
      { title: "Chapter 1: Physics Mechanics", pages: 48 },
      { title: "Chapter 2: Electricity", pages: 32 },
      { title: "Chapter 3: Chemistry Basics", pages: 40 },
      { title: "Chapter 4: Organic Chemistry", pages: 44 },
    ],
  },
  {
    id: "english",
    name: "English",
    chapters: [
      { title: "Chapter 1: Grammar", pages: 30 },
      { title: "Chapter 2: Literature", pages: 52 },
      { title: "Chapter 3: Essay Writing", pages: 28 },
      { title: "Chapter 4: Poetry", pages: 36 },
    ],
  },
  {
    id: "history",
    name: "History",
    chapters: [
      { title: "Chapter 1: Ancient History", pages: 46 },
      { title: "Chapter 2: Medieval Period", pages: 38 },
      { title: "Chapter 3: Modern Era", pages: 42 },
      { title: "Chapter 4: World Wars", pages: 50 },
    ],
  },
]

