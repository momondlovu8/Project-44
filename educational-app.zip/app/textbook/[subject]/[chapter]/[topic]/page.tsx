"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, ChevronLeft, ChevronRight, Download, Heart, Search, Settings, FileText } from "lucide-react"
import Link from "next/link"
import { useState, useEffect } from "react"

export default function TopicPage({
  params,
}: {
  params: { subject: string; chapter: string; topic: string }
}) {
  const [fontSize, setFontSize] = useState(16)
  const [isHighlighting, setIsHighlighting] = useState(false)
  const [highlights, setHighlights] = useState<string[]>([])
  const [notes, setNotes] = useState<{ [key: string]: string }>({})
  const [showNoteInput, setShowNoteInput] = useState<string | null>(null)
  const [noteText, setNoteText] = useState("")

  const subjectData = getSubjectData(params.subject)
  const chapterIndex = Number.parseInt(params.chapter) - 1
  const topicIndex = Number.parseInt(params.topic) - 1

  const chapterTitle = subjectData.chapters[chapterIndex]?.title || "Chapter"
  const topicTitle = subjectData.chapters[chapterIndex]?.topics[topicIndex] || "Topic"

  const nextTopic = getNextTopic(params.subject, chapterIndex, topicIndex)
  const prevTopic = getPrevTopic(params.subject, chapterIndex, topicIndex)

  // Simulate loading content from offline storage
  useEffect(() => {
    // This would normally check if content is available offline
    console.log("Checking if content is available offline...")
  }, [params.subject, params.chapter, params.topic])

  const handleTextSelection = () => {
    if (!isHighlighting) return

    const selection = window.getSelection()
    if (!selection || selection.toString().trim() === "") return

    const selectedText = selection.toString()
    setHighlights([...highlights, selectedText])

    // Clear selection after highlighting
    window.getSelection()?.removeAllRanges()
  }

  const addNote = (paragraph: string) => {
    setShowNoteInput(paragraph)
  }

  const saveNote = () => {
    if (showNoteInput && noteText.trim() !== "") {
      setNotes({
        ...notes,
        [showNoteInput]: noteText,
      })
    }
    setShowNoteInput(null)
    setNoteText("")
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-3 flex items-center">
          <Link href={`/textbook/${params.subject}`} className="mr-3">
            <ChevronLeft className="h-5 w-5" />
          </Link>
          <div className="flex-1">
            <h1 className="text-lg font-bold">{topicTitle}</h1>
            <p className="text-sm text-muted-foreground">{chapterTitle}</p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsHighlighting(!isHighlighting)}
              className={isHighlighting ? "bg-yellow-100 text-yellow-600 dark:bg-yellow-900 dark:text-yellow-300" : ""}
            >
              <Heart className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Download className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="flex justify-end mb-4 gap-2">
          <Button variant="outline" size="sm" onClick={() => setFontSize(Math.max(12, fontSize - 2))}>
            A-
          </Button>
          <Button variant="outline" size="sm" onClick={() => setFontSize(Math.min(24, fontSize + 2))}>
            A+
          </Button>
        </div>

        <Tabs defaultValue="content" className="w-full mb-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="content">Content</TabsTrigger>
            <TabsTrigger value="highlights">Highlights</TabsTrigger>
            <TabsTrigger value="notes">Notes</TabsTrigger>
          </TabsList>
          <TabsContent value="content">
            <div
              className="prose dark:prose-invert max-w-none"
              style={{ fontSize: `${fontSize}px` }}
              onMouseUp={handleTextSelection}
            >
              <h2>{topicTitle}</h2>

              {generateParagraphs(params.subject, chapterIndex, topicIndex).map((paragraph, index) => (
                <div key={index} className="mb-4 relative">
                  <p>{paragraph}</p>
                  <div className="flex justify-end mt-1">
                    <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => addNote(paragraph)}>
                      Add Note
                    </Button>
                  </div>

                  {showNoteInput === paragraph && (
                    <Card className="p-3 mt-2">
                      <textarea
                        className="w-full p-2 border rounded-md mb-2 bg-background"
                        rows={3}
                        placeholder="Add your note here..."
                        value={noteText}
                        onChange={(e) => setNoteText(e.target.value)}
                      />
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" size="sm" onClick={() => setShowNoteInput(null)}>
                          Cancel
                        </Button>
                        <Button size="sm" onClick={saveNote}>
                          Save
                        </Button>
                      </div>
                    </Card>
                  )}

                  {notes[paragraph] && (
                    <Card className="p-3 mt-2 bg-muted/50">
                      <p className="text-sm">{notes[paragraph]}</p>
                    </Card>
                  )}
                </div>
              ))}

              <div className="flex justify-between mt-8">
                {prevTopic ? (
                  <Button asChild variant="outline">
                    <Link href={`/textbook/${params.subject}/${prevTopic.chapter}/${prevTopic.topic}`}>
                      <ChevronLeft className="h-4 w-4 mr-2" />
                      Previous: {prevTopic.title}
                    </Link>
                  </Button>
                ) : (
                  <div></div>
                )}

                {nextTopic ? (
                  <Button asChild>
                    <Link href={`/textbook/${params.subject}/${nextTopic.chapter}/${nextTopic.topic}`}>
                      Next: {nextTopic.title}
                      <ChevronRight className="h-4 w-4 ml-2" />
                    </Link>
                  </Button>
                ) : (
                  <div></div>
                )}
              </div>
            </div>
          </TabsContent>
          <TabsContent value="highlights">
            <div className="space-y-4">
              {highlights.length > 0 ? (
                highlights.map((highlight, index) => (
                  <Card key={index} className="p-4">
                    <blockquote className="border-l-4 border-primary pl-4 italic">{highlight}</blockquote>
                  </Card>
                ))
              ) : (
                <div className="text-center p-8 text-muted-foreground">
                  <p>No highlights yet</p>
                  <p className="text-sm mt-2">
                    Toggle the highlight button and select text to highlight important information
                  </p>
                </div>
              )}
            </div>
          </TabsContent>
          <TabsContent value="notes">
            <div className="space-y-4">
              {Object.keys(notes).length > 0 ? (
                Object.entries(notes).map(([paragraph, note], index) => (
                  <Card key={index} className="p-4">
                    <blockquote className="border-l-4 border-muted pl-4 mb-2 text-sm text-muted-foreground">
                      {paragraph.length > 100 ? paragraph.substring(0, 100) + "..." : paragraph}
                    </blockquote>
                    <p>{note}</p>
                  </Card>
                ))
              ) : (
                <div className="text-center p-8 text-muted-foreground">
                  <p>No notes yet</p>
                  <p className="text-sm mt-2">Click "Add Note" on any paragraph to add your notes</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <footer className="border-t py-2">
        <div className="container mx-auto">
          <nav className="flex justify-around">
            <Link href="/" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Home</span>
            </Link>
            <Link href="/textbook" className="flex flex-col items-center p-2 text-primary">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Textbook</span>
            </Link>
            <Link href="/exams" className="flex flex-col items-center p-2">
              <FileText className="h-5 w-5" />
              <span className="text-xs">Exams</span>
            </Link>
            <Link href="/search" className="flex flex-col items-center p-2">
              <Search className="h-5 w-5" />
              <span className="text-xs">Search</span>
            </Link>
            <Link href="/settings" className="flex flex-col items-center p-2">
              <Settings className="h-5 w-5" />
              <span className="text-xs">Settings</span>
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}

function getSubjectData(subjectId: string) {
  const subjects = {
    mathematics: {
      name: "Mathematics",
      chapters: [
        {
          title: "Algebra",
          pages: 42,
          topics: ["Linear Equations", "Quadratic Equations", "Polynomials", "Factorization", "Algebraic Fractions"],
        },
        {
          title: "Functions",
          pages: 38,
          topics: [
            "Function Notation",
            "Domain and Range",
            "Linear Functions",
            "Quadratic Functions",
            "Exponential Functions",
          ],
        },
        {
          title: "Calculus",
          pages: 45,
          topics: [
            "Limits",
            "Derivatives",
            "Applications of Derivatives",
            "Integration",
            "Applications of Integration",
          ],
        },
        {
          title: "Trigonometry",
          pages: 36,
          topics: [
            "Trigonometric Ratios",
            "Trigonometric Functions",
            "Trigonometric Identities",
            "Solving Triangles",
            "Applications of Trigonometry",
          ],
        },
      ],
    },
    science: {
      name: "Science",
      chapters: [
        {
          title: "Physics Mechanics",
          pages: 48,
          topics: [
            "Newton's Laws of Motion",
            "Forces and Motion",
            "Work, Energy, and Power",
            "Momentum and Collisions",
            "Circular Motion",
          ],
        },
        {
          title: "Electricity",
          pages: 32,
          topics: [
            "Electric Charge",
            "Electric Fields",
            "Electric Potential",
            "Electric Circuits",
            "Magnetism and Electromagnetism",
          ],
        },
        {
          title: "Chemistry Basics",
          pages: 40,
          topics: ["Atomic Structure", "Periodic Table", "Chemical Bonding", "Chemical Reactions", "Stoichiometry"],
        },
        {
          title: "Organic Chemistry",
          pages: 44,
          topics: ["Hydrocarbons", "Functional Groups", "Organic Reactions", "Polymers", "Biochemistry"],
        },
      ],
    },
    english: {
      name: "English",
      chapters: [
        {
          title: "Grammar",
          pages: 30,
          topics: ["Parts of Speech", "Sentence Structure", "Punctuation", "Tenses", "Active and Passive Voice"],
        },
        {
          title: "Literature",
          pages: 52,
          topics: [
            "Literary Genres",
            "Elements of Fiction",
            "Character Analysis",
            "Theme Analysis",
            "Literary Devices",
          ],
        },
        {
          title: "Essay Writing",
          pages: 28,
          topics: [
            "Essay Structure",
            "Argumentative Essays",
            "Descriptive Essays",
            "Narrative Essays",
            "Research Papers",
          ],
        },
        {
          title: "Poetry",
          pages: 36,
          topics: ["Poetic Forms", "Poetic Devices", "Rhythm and Meter", "Analyzing Poetry", "Writing Poetry"],
        },
      ],
    },
    history: {
      name: "History",
      chapters: [
        {
          title: "Ancient History",
          pages: 46,
          topics: ["Early Civilizations", "Ancient Egypt", "Ancient Greece", "Ancient Rome", "Ancient China"],
        },
        {
          title: "Medieval Period",
          pages: 38,
          topics: ["Feudalism", "The Crusades", "Medieval Europe", "Islamic Golden Age", "Byzantine Empire"],
        },
        {
          title: "Modern Era",
          pages: 42,
          topics: ["Renaissance", "Industrial Revolution", "Colonialism", "Nationalism", "Imperialism"],
        },
        {
          title: "World Wars",
          pages: 50,
          topics: ["Causes of World War I", "World War I", "Interwar Period", "World War II", "Cold War"],
        },
      ],
    },
  }

  return subjects[subjectId as keyof typeof subjects] || subjects.mathematics
}

function getNextTopic(subject: string, chapterIndex: number, topicIndex: number) {
  const subjectData = getSubjectData(subject)
  const chapter = subjectData.chapters[chapterIndex]

  if (!chapter) return null

  // If there's another topic in the same chapter
  if (topicIndex < chapter.topics.length - 1) {
    return {
      chapter: chapterIndex + 1,
      topic: topicIndex + 2,
      title: chapter.topics[topicIndex + 1],
    }
  }

  // If there's another chapter
  if (chapterIndex < subjectData.chapters.length - 1) {
    return {
      chapter: chapterIndex + 2,
      topic: 1,
      title: subjectData.chapters[chapterIndex + 1].topics[0],
    }
  }

  return null
}

function getPrevTopic(subject: string, chapterIndex: number, topicIndex: number) {
  const subjectData = getSubjectData(subject)

  // If there's a previous topic in the same chapter
  if (topicIndex > 0) {
    return {
      chapter: chapterIndex + 1,
      topic: topicIndex,
      title: subjectData.chapters[chapterIndex].topics[topicIndex - 1],
    }
  }

  // If there's a previous chapter
  if (chapterIndex > 0) {
    const prevChapter = subjectData.chapters[chapterIndex - 1]
    return {
      chapter: chapterIndex,
      topic: prevChapter.topics.length,
      title: prevChapter.topics[prevChapter.topics.length - 1],
    }
  }

  return null
}

function generateParagraphs(subject: string, chapterIndex: number, topicIndex: number) {
  // This would normally come from a database or content API
  // For demo purposes, we'll generate some placeholder content
  const subjectData = getSubjectData(subject)
  const chapter = subjectData.chapters[chapterIndex]
  const topic = chapter?.topics[topicIndex] || "Topic"

  const paragraphs = [
    `This section covers the fundamentals of ${topic} in ${chapter?.title}. It's an essential concept in ${subjectData.name} that builds upon previous knowledge and prepares you for more advanced topics.`,
    `${topic} involves understanding key principles and applying them to solve problems. Students often find this topic challenging at first, but with practice, it becomes more intuitive.`,
    `The history of ${topic} dates back to early mathematical discoveries. Scholars throughout history have contributed to our understanding of these concepts, refining them over centuries.`,
    `When working with ${topic}, it's important to follow a systematic approach. Begin by identifying the key variables and relationships, then apply the appropriate formulas or techniques to solve the problem.`,
    `Practice problems are essential for mastering ${topic}. Try working through examples with increasing difficulty to build your confidence and skills.`,
    `Real-world applications of ${topic} can be found in various fields, including engineering, economics, and natural sciences. Understanding these applications helps contextualize the theoretical concepts.`,
  ]

  return paragraphs
}

