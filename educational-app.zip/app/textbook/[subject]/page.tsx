"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, ChevronLeft, Download, Search, BookMarked } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

export default function SubjectPage({ params }: { params: { subject: string } }) {
  const [searchQuery, setSearchQuery] = useState("")
  const subject = getSubjectData(params.subject)

  const filteredChapters = subject.chapters.filter((chapter) =>
    chapter.title.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Create a flattened array of all topics with their chapter info for easier filtering
  const allTopics = subject.chapters.flatMap((chapter, chapterIndex) =>
    chapter.topics.map((topic, topicIndex) => ({
      topic,
      chapterTitle: chapter.title,
      chapterIndex,
      topicIndex,
    })),
  )

  const filteredTopics = allTopics.filter((item) => item.topic.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-3 flex items-center">
          <Link href="/textbook" className="mr-3">
            <ChevronLeft className="h-5 w-5" />
          </Link>
          <h1 className="text-xl font-bold flex items-center">
            <BookOpen className="mr-2 h-5 w-5" />
            {subject.name}
          </h1>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={`Search in ${subject.name}...`}
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <Tabs defaultValue="chapters" className="w-full mb-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="chapters">Chapters</TabsTrigger>
            <TabsTrigger value="topics">Topics</TabsTrigger>
            <TabsTrigger value="downloads">Downloads</TabsTrigger>
          </TabsList>
          <TabsContent value="chapters">
            <div className="grid gap-4 mt-4">
              {filteredChapters.map((chapter, index) => (
                <Card key={index} className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="flex items-center border-b">
                      <div className="p-4 flex-1">
                        <h3 className="font-medium">{chapter.title}</h3>
                        <p className="text-sm text-muted-foreground">{chapter.pages} pages</p>
                      </div>
                      <div className="flex gap-2 p-2">
                        <Button variant="ghost" size="icon">
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="p-4 grid gap-2">
                      {chapter.topics.map((topic, i) => (
                        <Link
                          key={i}
                          href={`/textbook/${params.subject}/${index + 1}/${i + 1}`}
                          className="flex justify-between items-center p-2 hover:bg-accent rounded-md"
                        >
                          <div className="flex items-center gap-2">
                            <BookMarked className="h-4 w-4 text-muted-foreground" />
                            <span>{topic}</span>
                          </div>
                          <ChevronLeft className="h-4 w-4 rotate-180" />
                        </Link>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="topics">
            <div className="grid gap-2 mt-4">
              {filteredTopics.map((item, index) => (
                <Link
                  key={index}
                  href={`/textbook/${params.subject}/${item.chapterIndex + 1}/${item.topicIndex + 1}`}
                  className="flex justify-between items-center p-3 border rounded-md hover:bg-accent"
                >
                  <div className="flex items-center gap-2">
                    <BookMarked className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <span className="block">{item.topic}</span>
                      <span className="text-sm text-muted-foreground">{item.chapterTitle}</span>
                    </div>
                  </div>
                  <ChevronLeft className="h-4 w-4 rotate-180" />
                </Link>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="downloads">
            <div className="grid gap-4 mt-4">
              <Card className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="flex items-center p-4">
                    <div className="flex-1">
                      <h3 className="font-medium">Chapter 1: {subject.chapters[0].title}</h3>
                      <p className="text-sm text-muted-foreground">Downloaded on March 15, 2023</p>
                    </div>
                    <Button variant="ghost" size="sm">
                      Open
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <div className="text-center p-6 text-muted-foreground">
                <p>Download more chapters for offline access</p>
                <Button variant="outline" className="mt-2">
                  <Download className="h-4 w-4 mr-2" />
                  Download All Chapters
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <footer className="border-t py-2">
        <div className="container mx-auto">
          <nav className="flex justify-around">
            <Link href="/" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Home</span>
            </Link>
            <Link href="/textbook" className="flex flex-col items-center p-2 text-primary">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Textbook</span>
            </Link>
            <Link href="/exams" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Exams</span>
            </Link>
            <Link href="/search" className="flex flex-col items-center p-2">
              <Search className="h-5 w-5" />
              <span className="text-xs">Search</span>
            </Link>
            <Link href="/settings" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Settings</span>
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}

function getSubjectData(subjectId: string) {
  const subjects = {
    mathematics: {
      name: "Mathematics",
      chapters: [
        {
          title: "Algebra",
          pages: 42,
          topics: ["Linear Equations", "Quadratic Equations", "Polynomials", "Factorization", "Algebraic Fractions"],
        },
        {
          title: "Functions",
          pages: 38,
          topics: [
            "Function Notation",
            "Domain and Range",
            "Linear Functions",
            "Quadratic Functions",
            "Exponential Functions",
          ],
        },
        {
          title: "Calculus",
          pages: 45,
          topics: [
            "Limits",
            "Derivatives",
            "Applications of Derivatives",
            "Integration",
            "Applications of Integration",
          ],
        },
        {
          title: "Trigonometry",
          pages: 36,
          topics: [
            "Trigonometric Ratios",
            "Trigonometric Functions",
            "Trigonometric Identities",
            "Solving Triangles",
            "Applications of Trigonometry",
          ],
        },
      ],
    },
    science: {
      name: "Science",
      chapters: [
        {
          title: "Physics Mechanics",
          pages: 48,
          topics: [
            "Newton's Laws of Motion",
            "Forces and Motion",
            "Work, Energy, and Power",
            "Momentum and Collisions",
            "Circular Motion",
          ],
        },
        {
          title: "Electricity",
          pages: 32,
          topics: [
            "Electric Charge",
            "Electric Fields",
            "Electric Potential",
            "Electric Circuits",
            "Magnetism and Electromagnetism",
          ],
        },
        {
          title: "Chemistry Basics",
          pages: 40,
          topics: ["Atomic Structure", "Periodic Table", "Chemical Bonding", "Chemical Reactions", "Stoichiometry"],
        },
        {
          title: "Organic Chemistry",
          pages: 44,
          topics: ["Hydrocarbons", "Functional Groups", "Organic Reactions", "Polymers", "Biochemistry"],
        },
      ],
    },
    english: {
      name: "English",
      chapters: [
        {
          title: "Grammar",
          pages: 30,
          topics: ["Parts of Speech", "Sentence Structure", "Punctuation", "Tenses", "Active and Passive Voice"],
        },
        {
          title: "Literature",
          pages: 52,
          topics: [
            "Literary Genres",
            "Elements of Fiction",
            "Character Analysis",
            "Theme Analysis",
            "Literary Devices",
          ],
        },
        {
          title: "Essay Writing",
          pages: 28,
          topics: [
            "Essay Structure",
            "Argumentative Essays",
            "Descriptive Essays",
            "Narrative Essays",
            "Research Papers",
          ],
        },
        {
          title: "Poetry",
          pages: 36,
          topics: ["Poetic Forms", "Poetic Devices", "Rhythm and Meter", "Analyzing Poetry", "Writing Poetry"],
        },
      ],
    },
    history: {
      name: "History",
      chapters: [
        {
          title: "Ancient History",
          pages: 46,
          topics: ["Early Civilizations", "Ancient Egypt", "Ancient Greece", "Ancient Rome", "Ancient China"],
        },
        {
          title: "Medieval Period",
          pages: 38,
          topics: ["Feudalism", "The Crusades", "Medieval Europe", "Islamic Golden Age", "Byzantine Empire"],
        },
        {
          title: "Modern Era",
          pages: 42,
          topics: ["Renaissance", "Industrial Revolution", "Colonialism", "Nationalism", "Imperialism"],
        },
        {
          title: "World Wars",
          pages: 50,
          topics: ["Causes of World War I", "World War I", "Interwar Period", "World War II", "Cold War"],
        },
      ],
    },
  }

  return subjects[subjectId as keyof typeof subjects] || subjects.mathematics
}

