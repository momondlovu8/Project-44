"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, ChevronLeft, FileText, Search, Settings } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<SearchResult[]>([])
  const [isSearching, setIsSearching] = useState(false)

  const handleSearch = () => {
    if (!searchQuery.trim()) return

    setIsSearching(true)

    // Simulate search delay
    setTimeout(() => {
      const results = performSearch(searchQuery)
      setSearchResults(results)
      setIsSearching(false)
    }, 500)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch()
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-3 flex items-center">
          <Link href="/" className="mr-3">
            <ChevronLeft className="h-5 w-5" />
          </Link>
          <h1 className="text-xl font-bold flex items-center">
            <Search className="mr-2 h-5 w-5" />
            Search
          </h1>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="relative mb-6 flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search for topics, concepts, or questions..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleKeyDown}
            />
          </div>
          <Button onClick={handleSearch} disabled={isSearching}>
            {isSearching ? "Searching..." : "Search"}
          </Button>
        </div>

        {searchResults.length > 0 && (
          <Tabs defaultValue="all" className="w-full mb-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all">All ({searchResults.length})</TabsTrigger>
              <TabsTrigger value="textbook">
                Textbook ({searchResults.filter((r) => r.type === "textbook").length})
              </TabsTrigger>
              <TabsTrigger value="exams">Exams ({searchResults.filter((r) => r.type === "exam").length})</TabsTrigger>
            </TabsList>
            <TabsContent value="all">
              <div className="space-y-4 mt-4">
                {searchResults.map((result, index) => (
                  <SearchResultItem key={index} result={result} />
                ))}
              </div>
            </TabsContent>
            <TabsContent value="textbook">
              <div className="space-y-4 mt-4">
                {searchResults
                  .filter((result) => result.type === "textbook")
                  .map((result, index) => (
                    <SearchResultItem key={index} result={result} />
                  ))}
              </div>
            </TabsContent>
            <TabsContent value="exams">
              <div className="space-y-4 mt-4">
                {searchResults
                  .filter((result) => result.type === "exam")
                  .map((result, index) => (
                    <SearchResultItem key={index} result={result} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        )}

        {searchQuery && !isSearching && searchResults.length === 0 && (
          <div className="text-center p-8">
            <p className="text-muted-foreground mb-2">No results found for "{searchQuery}"</p>
            <p className="text-sm text-muted-foreground">Try different keywords or check your spelling</p>
          </div>
        )}

        {!searchQuery && (
          <div className="text-center p-8">
            <p className="text-muted-foreground mb-2">Search across all your textbooks and exam papers</p>
            <p className="text-sm text-muted-foreground">Try searching for a topic, concept, or specific question</p>
          </div>
        )}
      </main>

      <footer className="border-t py-2">
        <div className="container mx-auto">
          <nav className="flex justify-around">
            <Link href="/" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Home</span>
            </Link>
            <Link href="/textbook" className="flex flex-col items-center p-2">
              <BookOpen className="h-5 w-5" />
              <span className="text-xs">Textbook</span>
            </Link>
            <Link href="/exams" className="flex flex-col items-center p-2">
              <FileText className="h-5 w-5" />
              <span className="text-xs">Exams</span>
            </Link>
            <Link href="/search" className="flex flex-col items-center p-2 text-primary">
              <Search className="h-5 w-5" />
              <span className="text-xs">Search</span>
            </Link>
            <Link href="/settings" className="flex flex-col items-center p-2">
              <Settings className="h-5 w-5" />
              <span className="text-xs">Settings</span>
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}

interface SearchResult {
  title: string
  subject: string
  chapter: string
  type: "textbook" | "exam"
  path: string
  excerpt: string
}

function SearchResultItem({ result }: { result: SearchResult }) {
  return (
    <Link href={result.path} className="block border rounded-lg p-4 hover:bg-accent transition-colors">
      <div className="flex items-start gap-3">
        <div className={`mt-1 rounded-full p-2 ${result.type === "textbook" ? "bg-primary/10" : "bg-secondary"}`}>
          {result.type === "textbook" ? (
            <BookOpen className="h-4 w-4 text-primary" />
          ) : (
            <FileText className="h-4 w-4" />
          )}
        </div>
        <div>
          <h3 className="font-medium">{result.title}</h3>
          <p className="text-sm text-muted-foreground">
            {result.subject} • {result.chapter}
          </p>
          <p className="text-sm mt-1">{result.excerpt}</p>
        </div>
      </div>
    </Link>
  )
}

function performSearch(query: string): SearchResult[] {
  // This would normally query a database or search API
  // For demo purposes, we'll return mock results based on the query

  if (!query.trim()) return []

  const lowerQuery = query.toLowerCase()

  const allPossibleResults: SearchResult[] = [
    {
      title: "Quadratic Equations",
      subject: "Mathematics",
      chapter: "Algebra",
      type: "textbook",
      path: "/textbook/mathematics/1/2",
      excerpt: "A quadratic equation is a second-degree polynomial equation in a single variable...",
    },
    {
      title: "Solving Quadratic Equations",
      subject: "Mathematics",
      chapter: "Algebra",
      type: "exam",
      path: "/exams/math-practice-1",
      excerpt: "Practice problems for solving quadratic equations using various methods...",
    },
    {
      title: "Trigonometric Functions",
      subject: "Mathematics",
      chapter: "Trigonometry",
      type: "textbook",
      path: "/textbook/mathematics/4/2",
      excerpt: "Trigonometric functions relate the angles of a triangle to the lengths of its sides...",
    },
    {
      title: "Chemical Reactions",
      subject: "Science",
      chapter: "Chemistry Basics",
      type: "textbook",
      path: "/textbook/science/3/4",
      excerpt: "Chemical reactions occur when chemical substances called reactants transform into products...",
    },
    {
      title: "Balancing Chemical Equations",
      subject: "Science",
      chapter: "Chemistry Basics",
      type: "exam",
      path: "/exams/science-practice-1",
      excerpt: "Practice problems for balancing chemical equations and identifying reaction types...",
    },
    {
      title: "Essay Structure",
      subject: "English",
      chapter: "Essay Writing",
      type: "textbook",
      path: "/textbook/english/3/1",
      excerpt: "A well-structured essay includes an introduction, body paragraphs, and a conclusion...",
    },
    {
      title: "World War II",
      subject: "History",
      chapter: "World Wars",
      type: "textbook",
      path: "/textbook/history/4/4",
      excerpt: "World War II was a global conflict that lasted from 1939 to 1945, involving many nations...",
    },
    {
      title: "Causes of World War II",
      subject: "History",
      chapter: "World Wars",
      type: "exam",
      path: "/exams/history-past-1",
      excerpt:
        "Examine the political, economic, and social factors that contributed to the outbreak of World War II...",
    },
  ]

  // Filter results based on the query
  return allPossibleResults.filter(
    (result) =>
      result.title.toLowerCase().includes(lowerQuery) ||
      result.subject.toLowerCase().includes(lowerQuery) ||
      result.chapter.toLowerCase().includes(lowerQuery) ||
      result.excerpt.toLowerCase().includes(lowerQuery),
  )
}

